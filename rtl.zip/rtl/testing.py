# rtl/testing.py
import os
from pathlib import Path
from cocotb_tools.runner import get_runner

def test_ascon_runner():
    # SWITCH THIS TO VERILATOR
    sim = "verilator"
    proj_path = Path(__file__).resolve().parent

    runner = get_runner(sim)
    
    # Verilator reads the top-level file and automatically resolves the includes!
    runner.build(
        sources=[proj_path / "ascon_core.sv"],
        hdl_toplevel="ascon_core",
        includes=[proj_path],
        build_args=["--trace"] # This enables waveform generation (.vcd files) automatically
    )

    runner.test(
        hdl_toplevel="ascon_core",
        test_module="test_ascon_core",  
    )

if __name__ == "__main__":
    test_ascon_runner()