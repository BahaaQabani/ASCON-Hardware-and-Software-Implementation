# rtl/test_ascon_core.py
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, Timer

# ---> IMPORT YOUR SOFTWARE IMPLEMENTATION HERE <---
# Assuming your software file is named 'ascon_software.py' and has a function 'ascon_encrypt'
# from ascon_software import ascon_encrypt

def run_software_ref(key, nonce, associated_data, plaintext):
    """
    Wrapper function representing your finished software implementation.
    Replace this placeholder logic with your actual software function!
    """
    # For example: return ascon_encrypt(key, nonce, associated_data, plaintext)
    fake_ciphertext = 0xABCDEF12  # Placeholder
    return fake_ciphertext


@cocotb.test()
async def test_ascon_crypto_compare(dut):
    """Drive cryptographic inputs to both the Hardware (DUT) and Software reference"""
    
    # 1. Start the simulation clock (100 MHz)
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())
    
    # 2. Define your test vectors
    test_key   = 0x000102030405060708090A0B0C0D0E0F
    test_nonce = 0x000102030405060708090A0B0C0D0E0F
    test_data  = 0x41424344 # "ABCD"
    
    # 3. Apply a Hardware Reset
    dut.rst.value = 1
    dut.key_valid.value = 0
    dut.bdi_valid.value = 0
    dut.bdo_ready.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.rst.value = 0
    await RisingEdge(dut.clk)

    # 4. Run your finished Software Implementation to get the reference answer
    expected_result = run_software_ref(test_key, test_nonce, test_data, plaintext=None)
    dut._log.info(f"Software Reference Result: {hex(expected_result)}")

    # 5. Drive the inputs into the Verilog Core via its Handshake Protocol
    # (Setting key_valid high, waiting for the core to raise key_ready)
    dut.key.value = test_key
    dut.key_valid.value = 1
    
    while True:
        await RisingEdge(dut.clk)
        if int(dut.key_ready.value) == 1:
            break
            
    dut.key_valid.value = 0 # Clear key valid once absorbed
    await RisingEdge(dut.clk)

    # 6. Drive Block Data Inputs (bdi)
    dut.bdi.value = test_data
    dut.bdi_valid.value = 0xF # Assert all byte lanes valid
    
    while True:
        await RisingEdge(dut.clk)
        if int(dut.bdi_ready.value) == 1:
            break
            
    dut.bdi_valid.value = 0
    
    # 7. Wait for the Hardware Core to complete the permutation and output data (bdo)
    dut.bdo_ready.value = 1 # Tell core the testbench is ready to receive data
    
    while True:
        await RisingEdge(dut.clk)
        if int(dut.bdo_valid.value) == 1:
            break
            
    # 8. Read the final output directly from the hardware wires
    hardware_result = int(dut.bdo.value)
    dut._log.info(f"Hardware Core Result: {hex(hardware_result)}")

    # 9. THE COMPARISON CHECK
    # This assertion catches mismatches between your software and hardware instantly!
    assert hardware_result == expected_result, \
        f"MISMATCH! Software got {hex(expected_result)}, but Hardware got {hex(hardware_result)}"
        
    dut._log.info("SUCCESS: Hardware match verified against Python software implementation!")